#!/bin/bash

aws s3 cp s3://mydevopsbucket/main-binary/hello-world-app  /tmp/
