#!/bin/bash

chmod +x /tmp/hello-world-app
