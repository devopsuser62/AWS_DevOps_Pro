#!/bin/bash
aws s3 cp s3://kplabs-test-codebuild-bucket/main-binary/hello-world-app /tmp/
