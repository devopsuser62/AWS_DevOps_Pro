#!/bin/bash
/tmp/hello-world-app > /tmp/output.txt